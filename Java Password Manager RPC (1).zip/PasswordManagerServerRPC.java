package passwordmanager;

import javax.swing.*;
import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;

/**
 * Serveur RPC écoutant les requêtes des clients pour la gestion des mots de passe.
 */
public class PasswordManagerServerRPC {
    private static JTextArea logArea = new JTextArea();

    public static void main(String[] args) {
        JFrame frame = new JFrame("Serveur RPC - Logs");
        frame.setSize(500, 400);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        logArea.setEditable(false);
        frame.add(new JScrollPane(logArea));
        frame.setVisible(true);

        PasswordStore store = new PasswordStore();

        new Thread(() -> {
            try (ServerSocket server = new ServerSocket(5000)) {
                appendLog("✅ Serveur RPC démarré sur le port 5000...");
                while (true) {
                    Socket client = server.accept();
                    new Thread(() -> handleClient(client, store)).start();
                }
            } catch (IOException e) {
                appendLog("❌ Erreur serveur : " + e.getMessage());
            }
        }).start();
    }

    private static void handleClient(Socket client, PasswordStore store) {
        try (BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()));
             PrintWriter out = new PrintWriter(client.getOutputStream(), true)) {

            String[] parts = in.readLine().split(";", 4);
            String action = parts[0], user = parts[1], arg1 = parts[2], arg2 = parts[3];

            switch (action) {
                case "REGISTER" -> out.println(store.register(user, arg1) ? "OK" : "EXISTS");
                case "LOGIN"    -> out.println(store.login(user, arg1) ? "OK" : "FAIL");
                case "SAVE"     -> { store.save(user, arg1, arg2); out.println("SAVED"); }
                case "DELETE"   -> out.println(store.delete(user, arg1) ? "OK" : "NOT_FOUND");
                case "SEARCH"    -> {
                    String found = store.search(user, arg1);  // arg1 = service
                    out.println(found != null ? found : "NOT_FOUND");
                    break;}

                case "LIST"     -> {
                    for (var entry : store.list(user).entrySet()) {
                        out.println(entry.getKey() + ":" + entry.getValue());
                    }
                    out.println("END");
                }
            }
        } catch (Exception e) {
            appendLog("❗ Erreur client : " + e.getMessage());
        }
    }

    private static void appendLog(String message) {
        SwingUtilities.invokeLater(() -> logArea.append(message + "\n"));
    }
}
