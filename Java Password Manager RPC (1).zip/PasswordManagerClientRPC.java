package passwordmanager;

import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.net.Socket;

/**
 * Client RPC avec interface Swing pour gérer les mots de passe.
 * Version modifiée : ajout de "list" et suppression de "update".
 */
public class PasswordManagerClientRPC {
    private static String currentUser;

    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            showLoginWindow();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void showLoginWindow() {
        JFrame frame = new JFrame("🔐 Password Manager - Login/Register");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 250);
        frame.setLocationRelativeTo(null);

        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(new Color(240, 248, 255));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel lblUser = new JLabel("👤 Username:");
        JTextField tfUser = new JTextField(15);
        JLabel lblPass = new JLabel("🔑 Password:");
        JPasswordField pfPass = new JPasswordField(15);

        JButton btnLogin = new JButton("Login");
        JButton btnRegister = new JButton("Register");

        gbc.gridx = 0; gbc.gridy = 0; panel.add(lblUser, gbc);
        gbc.gridx = 1; panel.add(tfUser, gbc);
        gbc.gridx = 0; gbc.gridy = 1; panel.add(lblPass, gbc);
        gbc.gridx = 1; panel.add(pfPass, gbc);
        gbc.gridx = 0; gbc.gridy = 2; panel.add(btnLogin, gbc);
        gbc.gridx = 1; panel.add(btnRegister, gbc);

        frame.add(panel);
        frame.setVisible(true);

        btnLogin.addActionListener(e -> {
            String result = send("LOGIN", tfUser.getText(), new String(pfPass.getPassword()), "");
            if ("OK".equals(result)) {
                currentUser = tfUser.getText();
                frame.dispose();
                showMainWindow();
            } else {
                JOptionPane.showMessageDialog(frame, "❌ Login failed.");
            }
        });

        btnRegister.addActionListener(e -> {
            String result = send("REGISTER", tfUser.getText(), new String(pfPass.getPassword()), "");
            if ("OK".equals(result)) {
                JOptionPane.showMessageDialog(frame, "✅ Registration successful.");
            } else {
                JOptionPane.showMessageDialog(frame, "⚠️ User already exists.");
            }
        });
    }

    private static void showMainWindow() {
        JFrame frame = new JFrame("🔐 Password Manager - " + currentUser);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500, 400);
        frame.setLocationRelativeTo(null);
        frame.setLayout(new BorderLayout(10, 10));

        JPanel inputPanel = new JPanel(new GridBagLayout());
        inputPanel.setBackground(new Color(255, 255, 240));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel lblService = new JLabel("🌐 Service:");
        JTextField tfService = new JTextField(15);
        JLabel lblPassword = new JLabel("🔐 Password:");
        JTextField tfPassword = new JTextField(15);

        JButton btnSave = new JButton("💾 Save");
        JButton btnDelete = new JButton("🗑 Delete");
        JButton btnSearch = new JButton("🔍 Search");
        JButton btnList = new JButton("📋 List");
        JButton btnLogout = new JButton("🚪 Logout");

        gbc.gridx = 0; gbc.gridy = 0; inputPanel.add(lblService, gbc);
        gbc.gridx = 1; inputPanel.add(tfService, gbc);
        gbc.gridx = 0; gbc.gridy = 1; inputPanel.add(lblPassword, gbc);
        gbc.gridx = 1; inputPanel.add(tfPassword, gbc);
        gbc.gridx = 0; gbc.gridy = 2; inputPanel.add(btnSave, gbc);
        gbc.gridx = 1; inputPanel.add(btnDelete, gbc);
        gbc.gridx = 0; gbc.gridy = 3; inputPanel.add(btnSearch, gbc);
        gbc.gridx = 1; inputPanel.add(btnList, gbc);
        gbc.gridx = 0; gbc.gridy = 4; gbc.gridwidth = 2; inputPanel.add(btnLogout, gbc);

        JTextArea taOutput = new JTextArea();
        taOutput.setEditable(false);
        taOutput.setFont(new Font("Consolas", Font.PLAIN, 14));
        JScrollPane scrollPane = new JScrollPane(taOutput);

        frame.add(inputPanel, BorderLayout.NORTH);
        frame.add(scrollPane, BorderLayout.CENTER);

        btnSave.addActionListener(e -> {
            send("SAVE", currentUser, tfService.getText(), tfPassword.getText());
            JOptionPane.showMessageDialog(frame, "✅ Password saved.");
            tfService.setText(""); tfPassword.setText("");
        });

        btnDelete.addActionListener(e -> {
            String res = send("DELETE", currentUser, tfService.getText(), "");
            JOptionPane.showMessageDialog(frame, res.equals("OK") ? "🗑 Deleted." : "⚠ Not found.");
        });

        btnSearch.addActionListener(e -> {
            String res = send("SEARCH", currentUser, tfService.getText(), "");
            JOptionPane.showMessageDialog(frame, res.equals("NOT_FOUND") ? "❌ Not found." : "🔐 Password: " + res);
        });

        btnList.addActionListener(e -> {
            try (Socket socket = new Socket("localhost", 5000);
                 PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
                 BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()))) {

                out.println("LIST;" + currentUser + ";;");
                taOutput.setText("");
                String line;
                while (!(line = in.readLine()).equals("END")) {
                    taOutput.append("🔐 " + line + "\n");
                }

            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });

        btnLogout.addActionListener(e -> {
            frame.dispose();
            currentUser = null;
            showLoginWindow();
        });

        frame.setVisible(true);
    }

    private static String send(String action, String user, String arg1, String arg2) {
        try (Socket socket = new Socket("localhost", 5000);
             PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
             BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()))) {

            out.println(action + ";" + user + ";" + arg1 + ";" + arg2);
            return in.readLine();
        } catch (Exception e) {
            e.printStackTrace();
            return "ERROR";
        }
    }
}
