package passwordmanager;

import java.security.MessageDigest;
import java.util.HashMap;
import java.util.Map;

/**
 * Stockage sécurisé des utilisateurs et mots de passe en mémoire (version RPC).
 */
public class PasswordStore {
    private final Map<String, String> users = new HashMap<>();
    private final Map<String, Map<String, String>> passwords = new HashMap<>();

    public synchronized boolean register(String user, String pass) {
        if (users.containsKey(user)) return false;
        users.put(user, hash(pass));
        passwords.put(user, new HashMap<>());
        return true;
    }

    public synchronized boolean login(String user, String pass) {
        return users.containsKey(user) && users.get(user).equals(hash(pass));
    }

    public synchronized void save(String user, String service, String pwd) {
        passwords.get(user).put(service, pwd);
    }

    public synchronized boolean delete(String user, String service) {
        return passwords.containsKey(user) && passwords.get(user).remove(service) != null;
    }

    public synchronized String search(String user, String service) {
        return passwords.containsKey(user) ? passwords.get(user).get(service) : null;
    }


    public synchronized Map<String, String> list(String user) {
        return passwords.containsKey(user) ? new HashMap<>(passwords.get(user)) : new HashMap<>();
    }

    private String hash(String pwd) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] h = md.digest(pwd.getBytes("UTF-8"));
            StringBuilder sb = new StringBuilder();
            for (byte b : h) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
