package passwordmanager;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.Map;

/**
 * Interface RMI : définit les méthodes accessibles à distance.
 */
public interface PasswordManagerInterface extends Remote {
    boolean register(String username, String password) throws RemoteException;
    boolean login(String username, String password) throws RemoteException;
    boolean logout(String username) throws RemoteException;
    void savePassword(String service, String password, String username) throws RemoteException;
    boolean deletePassword(String service, String username) throws RemoteException;
    String searchPassword(String service, String username) throws RemoteException;
    Map<String, String> listPasswords(String username) throws RemoteException;
}
