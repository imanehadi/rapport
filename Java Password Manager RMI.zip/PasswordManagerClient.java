package passwordmanager;

import javax.swing.*;
import java.awt.*;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.Map;

/**
 * Client RMI avec interface Swing pour la gestion des mots de passe.
 * Version modifiée : méthode list ajoutée, méthode update supprimée.
 */
public class PasswordManagerClient {
    private static PasswordManagerInterface manager;
    private static String currentUser;

    public static void main(String[] args) {
        try {
            Registry registry = LocateRegistry.getRegistry("localhost", 1099);
            manager = (PasswordManagerInterface) registry.lookup("PasswordManager");
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            showLoginWindow();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void showLoginWindow() {
        JFrame frame = new JFrame("🔐 Login / Register");
        frame.setSize(400, 250);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(new Color(240, 248, 255));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);

        JTextField tfUser = new JTextField(15);
        JPasswordField pfPass = new JPasswordField(15);
        JButton btnLogin = new JButton("Login");
        JButton btnRegister = new JButton("Register");

        panel.add(new JLabel("👤 Username:"), gbc);
        gbc.gridx = 1;
        panel.add(tfUser, gbc);
        gbc.gridx = 0; gbc.gridy = 1;
        panel.add(new JLabel("🔑 Password:"), gbc);
        gbc.gridx = 1;
        panel.add(pfPass, gbc);
        gbc.gridy = 2; gbc.gridx = 0;
        panel.add(btnLogin, gbc);
        gbc.gridx = 1;
        panel.add(btnRegister, gbc);

        frame.add(panel);
        frame.setVisible(true);

        btnLogin.addActionListener(e -> {
            try {
                if (manager.login(tfUser.getText(), new String(pfPass.getPassword()))) {
                    currentUser = tfUser.getText();
                    frame.dispose();
                    showMainWindow();
                } else {
                    JOptionPane.showMessageDialog(frame, "❌ Login failed.");
                }
            } catch (Exception ex) { ex.printStackTrace(); }
        });

        btnRegister.addActionListener(e -> {
            try {
                if (manager.register(tfUser.getText(), new String(pfPass.getPassword()))) {
                    JOptionPane.showMessageDialog(frame, "✅ Registration successful.");
                } else {
                    JOptionPane.showMessageDialog(frame, "⚠️ User already exists.");
                }
            } catch (Exception ex) { ex.printStackTrace(); }
        });
    }

    private static void showMainWindow() {
        JFrame frame = new JFrame("🔐 Password Manager - " + currentUser);
        frame.setSize(500, 400);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JTextField tfService = new JTextField(15);
        JTextField tfPassword = new JTextField(15);
        JTextArea taOutput = new JTextArea();
        taOutput.setEditable(false);

        JButton btnSave = new JButton("💾 Save");
        JButton btnDelete = new JButton("🗑 Delete");
        JButton btnSearch = new JButton("🔍 Search");
        JButton btnList = new JButton("📋 List");
        JButton btnLogout = new JButton("🚪 Logout");

        JPanel panel = new JPanel(new GridLayout(0, 2, 5, 5));
        panel.add(new JLabel("Service:")); panel.add(tfService);
        panel.add(new JLabel("Password:")); panel.add(tfPassword);
        panel.add(btnSave); panel.add(btnDelete);
        panel.add(btnSearch); panel.add(btnList);
        panel.add(btnLogout);

        frame.setLayout(new BorderLayout());
        frame.add(panel, BorderLayout.NORTH);
        frame.add(new JScrollPane(taOutput), BorderLayout.CENTER);

        btnSave.addActionListener(e -> {
            try {
                manager.savePassword(tfService.getText(), tfPassword.getText(), currentUser);
                taOutput.append("✅ Saved\n");
            } catch (Exception ex) { ex.printStackTrace(); }
        });

        btnDelete.addActionListener(e -> {
            try {
                String service = tfService.getText().trim();
                System.out.println("Suppression demandée : user = " + currentUser + ", service = '" + service + "'");
                if (manager.deletePassword(service, currentUser)) {
                    taOutput.append("🗑 Deleted ");
                } else {
                    taOutput.append("❌ Not found ");
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });

        btnSearch.addActionListener(e -> {
            try {
                String res = manager.searchPassword(tfService.getText(), currentUser);
                taOutput.append(res != null ? "🔐 " + res + "\n" : "❌ Not found\n");
            } catch (Exception ex) { ex.printStackTrace(); }
        });

        btnList.addActionListener(e -> {
            try {
                taOutput.setText("");
                Map<String, String> map = manager.listPasswords(currentUser);
                if (map.isEmpty()) {
                    taOutput.append("📭 No passwords found\n");
                } else {
                    for (Map.Entry<String, String> entry : map.entrySet()) {
                        taOutput.append("🔐 " + entry.getKey() + " : " + entry.getValue() + "\n");
                    }
                }
            } catch (Exception ex) { ex.printStackTrace(); }
        });

        btnLogout.addActionListener(e -> {
            try {
                manager.logout(currentUser);
                frame.dispose();
                showLoginWindow();
            } catch (Exception ex) { ex.printStackTrace(); }
        });

        frame.setVisible(true);
    }
}

