package passwordmanager;

import java.rmi.server.UnicastRemoteObject;
import java.rmi.RemoteException;
import java.util.*;
import java.security.MessageDigest;
import java.nio.charset.StandardCharsets;

/**
 * Implémentation de l'interface RMI. Gère les mots de passe.
 */
public class PasswordManagerImpl extends UnicastRemoteObject implements PasswordManagerInterface {
    private final Map<String, String> users = new HashMap<>();
    private final Map<String, Map<String, String>> passwords = new HashMap<>();
    private final Set<String> loggedInUsers = new HashSet<>();

    public PasswordManagerImpl() throws RemoteException {}

    public synchronized boolean register(String username, String password) {
        if (users.containsKey(username)) return false;
        users.put(username, hash(password));
        passwords.put(username, new HashMap<>());
        return true;
    }

    public synchronized boolean login(String username, String password) {
        boolean ok = users.containsKey(username) && users.get(username).equals(hash(password));
        if (ok) loggedInUsers.add(username);
        return ok;
    }

    public synchronized boolean logout(String username) {
        return loggedInUsers.remove(username);
    }

    public synchronized void savePassword(String service, String password, String username) {
        if (loggedInUsers.contains(username)) {
            passwords.get(username).put(service, password);
        }
    }

    public synchronized boolean deletePassword(String service, String username) {
        return loggedInUsers.contains(username)
                && passwords.get(username).remove(service) != null;
    }

    public synchronized String searchPassword(String service, String username) {
        if (loggedInUsers.contains(username)) {
            return passwords.getOrDefault(username, new HashMap<>()).get(service);
        }
        return null;
    }

    public synchronized Map<String, String> listPasswords(String username) {
        if (loggedInUsers.contains(username)) {
            return new HashMap<>(passwords.getOrDefault(username, new HashMap<>()));
        }
        return Collections.emptyMap();
    }

    private static String hash(String input) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] bytes = md.digest(input.getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : bytes) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (Exception e) {
            throw new RuntimeException("Hash error", e);
        }
    }
}
