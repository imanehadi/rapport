package passwordmanager;

import javax.swing.*;
import java.awt.*;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

/**
 * Serveur RMI avec interface graphique pour visualiser les connexions et actions.
 */
public class PasswordManagerServer {

    private static JTextArea logArea;

    public static void main(String[] args) {
        // Interface graphique
        JFrame frame = new JFrame("🖥️ Serveur Password Manager (RMI)");
        frame.setSize(600, 400);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        logArea = new JTextArea();
        logArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(logArea);
        frame.add(scrollPane, BorderLayout.CENTER);
        frame.setVisible(true);

        try {
            PasswordManagerImpl server = new PasswordManagerImpl();

            Registry registry = LocateRegistry.createRegistry(1099);
            registry.rebind("PasswordManager", server);

            appendLog("✅ Serveur RMI démarré sur le port 1099.");
        } catch (Exception e) {
            appendLog("❌ Erreur serveur : " + e.getMessage());
            e.printStackTrace();
        }
    }

    private static void appendLog(String message) {
        SwingUtilities.invokeLater(() -> logArea.append(message + "\n"));
    }
}
